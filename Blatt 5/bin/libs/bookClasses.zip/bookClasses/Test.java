/**
 * Class for simple testing
 * 
 * Copyright Georgia Institute of Technology 2004
 * @author Barb Ericson ericson@cc.gatech.edu
 */
public class Test 
{
  public static void main (String[] args) 
  {
    // replace the lines below to test something else
    System.out.println(34 + 56);
    System.out.println(26 - 3);
    System.out.println(3 * 4);
    System.out.println(4/2);
  }
} // end of Test class